const express = require('express');
const app = express();
const router = express.Router();
const fs = require('fs')
// Reading JSON
const jsonString=fs.readFileSync("./user.json")
// Convert to read of JSON FILE /
const display_all_info =JSON.parse(jsonString)








/*
- Create new html file name home.html 
- add <h1> tag with message "Welcome to ExpressJs Tutorial"
- Return home.html page to client
*/
router.get('/home', (req,res) => {
  res.send('Welcome to ExpressJs Tutorial');
});

/*
- Return all details from user.json file to client as JSON format
*/
router.get('/profile', (req,res) => {
  res.send(display_all_info);
  
});

/*
- Modify /login router to accept username and password as query string parameter
- Read data from user.json file
- If username and  passsword is valid then send resonse as below 
    {
        status: true,
        message: "User Is valid"
    }
- If username is invalid then send response as below 
    {
        status: false,
        message: "User Name is invalid"
    }
- If passsword is invalid then send response as below 
    {
        status: false,
        message: "Password is invalid"
    }
*/


router.get('/login/:pusername/:ppassword', (req,res) => {
  const usr_name = req.params.pusername;
  const usr_password =req.params.ppassword;

  if(display_all_info["username"] ==usr_name && display_all_info["password"]==usr_password){
    res.send({
      status: true,
       message:'User  is valid'
    });
  }

  if(display_all_info["username"]!=usr_name){
    res.send({
      status: false,
       message:'User Name is invalid'
    });
  }

  if(display_all_info["password"]!=usr_password ){
    res.send({
      status: false,
       message:'Password is invalid'
    });
  }
  
  
  res.send('This is login router');
});

/*
- Modify /logout route to accept username as parameter and display message
    in HTML format like <b>${username} successfully logout.<b>
*/
router.get('/logout/:pusername', (req,res) => {
  const usr_name = req.params.pusername;
  if(display_all_info["username"] ==usr_name){
    res.send(`${usr_name} successfully logout.`);
  }else{
    res.send(`invalid username to logout` );

  }
  
});

app.use('/', router);

app.listen(process.env.port || 8081);

console.log('Web Server is listening at port '+ (process.env.port || 8081));